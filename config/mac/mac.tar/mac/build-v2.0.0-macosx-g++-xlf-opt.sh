#!/bin/sh

###################################################
# Set installation and build parameters
###################################################
TOP_DIR=`pwd`
SRC_DIR="${TOP_DIR}/SAMRAI"
OBJ_DIR="${TOP_DIR}/macosx-g++-xlf-opt"
INSTALL_DIR="/Users/kchu/usr/local/SAMRAI-v2.0.0"


###################################################
# Set compilers and flags
###################################################
CC=gcc
CXX=g++
F77=xlf
FFLAGS_EXTRA=-qextname
FC=xlf
export CC CXX F77 FFLAGS_EXTRA FC 


###################################################
# Configure build
###################################################
if [ -d "${OBJ_DIR}" ]; then
  rm -rf ${OBJ_DIR}
fi
mkdir ${OBJ_DIR}
cd ${OBJ_DIR}
${SRC_DIR}/configure 							\
           --prefix=${INSTALL_DIR}					\
           --enable-opt=-O3						\
           --with-fortran-libs=-lxlfmath				\
           --with-x							\
           --with-hdf5=/Users/kchu/usr/local/hdf5			\
           --without-petsc


###################################################
# Fixes (i.e. hacks) for config/Makefile.config
###################################################
cd config

# for Mac OS X, manually strip out the offending libraries in link flags
strrep Makefile.config "-lcrt1.o" ""
strrep Makefile.config "-lcrt2.o" ""
strrep Makefile.config "-lfrtbegin" ""
strrep Makefile.config "-lgcc" ""
strrep Makefile.config "-lSystem" ""

# fix order of MPICH libraries in link flags
strrep Makefile.config "-lpmpich -lmpich" "-lmpich -lpmpich"

cd .. # get back to top of object directory


###################################################
# Build library
###################################################
make library
cd lib; ranlib -s *.a; cd ..; # fix up table of contents for archives


###################################################
# install library 
###################################################
if [ -d "${INSTALL_DIR}" ]; then
  rm -rf "${INSTALL_DIR}"
fi
strrep Makefile "^install:" install-samrai:  # takes care of case-insensitivity
make install-samrai                          # for Mac OS X
cd ${INSTALL_DIR}/lib; ranlib -s *.a; # fix up table of contents for archives

# create symbolic link from ${INSTALL_DIR}/../SAMRAI to installed library
rm -f "${INSTALL_DIR}/../SAMRAI"
ln -s SAMRAI-v2.0.0 ${INSTALL_DIR}/../SAMRAI
